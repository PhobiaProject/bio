// Tower Defense - основной игровой скрипт

// 1. Звуковой движок (Web Audio API)
class AudioController {
  constructor() {
    this.ctx = null;
    this.isMuted = false;
    this.masterGain = null;
  }

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.value = 0.2;
        this.masterGain.connect(this.ctx.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : 0.2, this.ctx.currentTime);
    }
    return this.isMuted;
  }

  playShootGatling() {
    if (this.isMuted || !this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const t = this.ctx.currentTime;

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(550, t);
    osc.frequency.exponentialRampToValueAtTime(100, t + 0.07);

    gain.gain.setValueAtTime(0.25, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.07);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.07);
  }

  playShootCannon() {
    if (this.isMuted || !this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const t = this.ctx.currentTime;

    osc.type = 'sine';
    osc.frequency.setValueAtTime(120, t);
    osc.frequency.exponentialRampToValueAtTime(30, t + 0.2);

    gain.gain.setValueAtTime(0.5, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.2);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.2);
  }

  playExplosion() {
    if (this.isMuted || !this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const t = this.ctx.currentTime;

    osc.type = 'square';
    osc.frequency.setValueAtTime(80, t);
    osc.frequency.exponentialRampToValueAtTime(25, t + 0.25);

    gain.gain.setValueAtTime(0.35, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.25);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.25);
  }

  playShootFrost() {
    if (this.isMuted || !this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const t = this.ctx.currentTime;

    osc.type = 'sine';
    osc.frequency.setValueAtTime(700, t);
    osc.frequency.linearRampToValueAtTime(1100, t + 0.1);

    gain.gain.setValueAtTime(0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.1);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.1);
  }

  playShootTesla() {
    if (this.isMuted || !this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const t = this.ctx.currentTime;

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(240, t);
    osc.frequency.linearRampToValueAtTime(380, t + 0.08);

    gain.gain.setValueAtTime(0.15, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.08);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.08);
  }

  playShootSniper() {
    if (this.isMuted || !this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const t = this.ctx.currentTime;

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(1000, t);
    osc.frequency.exponentialRampToValueAtTime(80, t + 0.18);

    gain.gain.setValueAtTime(0.4, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.18);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.18);
  }

  playCoin() {
    if (this.isMuted || !this.ctx) return;
    const t = this.ctx.currentTime;
    [980, 1320].forEach((freq, idx) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const st = t + idx * 0.06;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, st);

      gain.gain.setValueAtTime(0.18, st);
      gain.gain.exponentialRampToValueAtTime(0.01, st + 0.12);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(st);
      osc.stop(st + 0.12);
    });
  }

  playBuild() {
    if (this.isMuted || !this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const t = this.ctx.currentTime;

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(280, t);
    osc.frequency.linearRampToValueAtTime(420, t + 0.1);

    gain.gain.setValueAtTime(0.25, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.1);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.1);
  }

  playUpgrade() {
    if (this.isMuted || !this.ctx) return;
    const t = this.ctx.currentTime;
    [520, 650, 780].forEach((f, i) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const st = t + i * 0.05;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, st);

      gain.gain.setValueAtTime(0.2, st);
      gain.gain.exponentialRampToValueAtTime(0.01, st + 0.12);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(st);
      osc.stop(st + 0.12);
    });
  }

  playWaveStart() {
    if (this.isMuted || !this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const t = this.ctx.currentTime;

    osc.type = 'sine';
    osc.frequency.setValueAtTime(320, t);
    osc.frequency.linearRampToValueAtTime(480, t + 0.2);

    gain.gain.setValueAtTime(0.3, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.25);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.25);
  }

  playVictory() {
    if (this.isMuted || !this.ctx) return;
    [523, 659, 784, 1046].forEach((f, i) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const st = this.ctx.currentTime + i * 0.1;

      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, st);

      gain.gain.setValueAtTime(0.25, st);
      gain.gain.exponentialRampToValueAtTime(0.01, st + 0.25);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(st);
      osc.stop(st + 0.25);
    });
  }

  playGameOver() {
    if (this.isMuted || !this.ctx) return;
    [380, 320, 260].forEach((f, i) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const st = this.ctx.currentTime + i * 0.15;

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(f, st);

      gain.gain.setValueAtTime(0.25, st);
      gain.gain.exponentialRampToValueAtTime(0.01, st + 0.25);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(st);
      osc.stop(st + 0.25);
    });
  }
}

// 2. Параметры башен и врагов
const TOWER_SPECS = {
  gatling: {
    name: 'Пулемет',
    cost: 100,
    range: 135,
    damage: 15,
    fireRate: 3.2,
    bulletSpeed: 11,
    splash: 0,
    color: '#38bdf8'
  },
  cannon: {
    name: 'Пушка',
    cost: 150,
    range: 155,
    damage: 60,
    fireRate: 0.9,
    bulletSpeed: 7,
    splash: 65,
    color: '#f97316'
  },
  frost: {
    name: 'Ледяная',
    cost: 175,
    range: 130,
    damage: 10,
    fireRate: 1.8,
    bulletSpeed: 9,
    splash: 40,
    slowFactor: 0.5,
    slowDuration: 3.0,
    color: '#06b6d4'
  },
  tesla: {
    name: 'Тесла',
    cost: 225,
    range: 145,
    damage: 10,
    fireRate: 8.0,
    bulletSpeed: 0,
    splash: 0,
    color: '#a855f7'
  },
  sniper: {
    name: 'Снайпер',
    cost: 275,
    range: 270,
    damage: 180,
    fireRate: 0.55,
    bulletSpeed: 18,
    splash: 0,
    color: '#22c55e'
  }
};

const ENEMY_TYPES = {
  scout: {
    name: 'Разведчик',
    color: '#22c55e',
    baseHp: 75,
    speed: 2.1,
    radius: 10,
    reward: 12,
    score: 25
  },
  soldier: {
    name: 'Пехотинец',
    color: '#38bdf8',
    baseHp: 170,
    speed: 1.35,
    radius: 12,
    reward: 18,
    score: 40
  },
  tank: {
    name: 'Голем',
    color: '#eab308',
    baseHp: 550,
    speed: 0.8,
    radius: 16,
    reward: 35,
    score: 80,
    armor: 0.25
  },
  runner: {
    name: 'Гончая',
    color: '#ef4444',
    baseHp: 110,
    speed: 2.7,
    radius: 9,
    reward: 20,
    score: 50
  },
  flyer: {
    name: 'Горгулья',
    color: '#c084fc',
    baseHp: 220,
    speed: 1.6,
    radius: 11,
    reward: 28,
    score: 65,
    immuneToSlow: true
  },
  boss: {
    name: 'Босс',
    color: '#e11d48',
    baseHp: 2400,
    speed: 0.65,
    radius: 20,
    reward: 150,
    score: 500,
    isBoss: true
  }
};

// 3. Карта и путь
class GameMap {
  constructor(cols = 24, rows = 15, tileSize = 40) {
    this.cols = cols;
    this.rows = rows;
    this.tileSize = tileSize;
    this.width = cols * tileSize;
    this.height = rows * tileSize;

    this.gridWaypoints = [
      { c: 0, r: 3 },
      { c: 5, r: 3 },
      { c: 5, r: 11 },
      { c: 11, r: 11 },
      { c: 11, r: 3 },
      { c: 17, r: 3 },
      { c: 17, r: 11 },
      { c: 23, r: 11 }
    ];

    this.pixelWaypoints = this.gridWaypoints.map(pt => ({
      x: pt.c * this.tileSize + this.tileSize / 2,
      y: pt.r * this.tileSize + this.tileSize / 2
    }));

    this.grid = Array(rows).fill(0).map(() => Array(cols).fill(0));
    this.markPathTiles();
  }

  markPathTiles() {
    for (let i = 0; i < this.gridWaypoints.length - 1; i++) {
      const p1 = this.gridWaypoints[i];
      const p2 = this.gridWaypoints[i + 1];

      const minC = Math.min(p1.c, p2.c);
      const maxC = Math.max(p1.c, p2.c);
      const minR = Math.min(p1.r, p2.r);
      const maxR = Math.max(p1.r, p2.r);

      for (let r = minR; r <= maxR; r++) {
        for (let c = minC; c <= maxC; c++) {
          this.grid[r][c] = 1;
        }
      }
    }
  }

  canBuildAt(col, row, towers) {
    if (col < 0 || col >= this.cols || row < 0 || row >= this.rows) return false;
    if (this.grid[row][col] !== 0) return false;
    return !towers.some(t => t.col === col && t.row === row);
  }

  draw(ctx) {
    // Фон сетки
    for (let r = 0; r < this.rows; r++) {
      for (let c = 0; c < this.cols; c++) {
        const x = c * this.tileSize;
        const y = r * this.tileSize;

        if (this.grid[r][c] === 1) {
          // Дорога
          ctx.fillStyle = '#222831';
          ctx.fillRect(x, y, this.tileSize, this.tileSize);
          ctx.strokeStyle = '#2d3748';
          ctx.lineWidth = 1;
          ctx.strokeRect(x, y, this.tileSize, this.tileSize);
        } else {
          // Трава / свободная зона
          const alt = (c + r) % 2 === 0;
          ctx.fillStyle = alt ? '#141a22' : '#11161d';
          ctx.fillRect(x, y, this.tileSize, this.tileSize);
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.02)';
          ctx.strokeRect(x, y, this.tileSize, this.tileSize);
        }
      }
    }

    // Маркер входа
    const pStart = this.pixelWaypoints[0];
    ctx.fillStyle = '#374151';
    ctx.fillRect(pStart.x - 18, pStart.y - 16, 12, 32);
    ctx.fillStyle = '#111827';
    ctx.fillRect(pStart.x - 14, pStart.y - 12, 8, 24);

    // Маркер базы
    const pEnd = this.pixelWaypoints[this.pixelWaypoints.length - 1];
    ctx.fillStyle = '#374151';
    ctx.fillRect(pEnd.x + 6, pEnd.y - 18, 14, 36);
    ctx.fillStyle = '#2563eb';
    ctx.fillRect(pEnd.x + 10, pEnd.y - 12, 6, 24);
  }
}

// 4. Враг
class Enemy {
  constructor(typeKey, waveNumber, waypoints) {
    this.typeKey = typeKey;
    const spec = ENEMY_TYPES[typeKey];
    this.spec = spec;

    const waveMultiplier = 1 + (waveNumber - 1) * 0.16;
    this.maxHp = Math.round(spec.baseHp * waveMultiplier);
    this.hp = this.maxHp;
    this.speed = spec.speed;
    this.baseSpeed = spec.speed;
    this.radius = spec.radius;
    this.reward = Math.round(spec.reward * (1 + (waveNumber - 1) * 0.05));
    this.score = spec.score;
    this.isBoss = !!spec.isBoss;
    this.armor = spec.armor || 0;
    this.immuneToSlow = !!spec.immuneToSlow;

    this.waypoints = waypoints;
    this.waypointIndex = 0;
    this.x = waypoints[0].x;
    this.y = waypoints[0].y;
    this.angle = 0;

    this.distanceTraveled = 0;
    this.slowTimer = 0;
    this.slowFactor = 1.0;

    this.isDead = false;
    this.reachedExit = false;
  }

  applySlow(factor, duration) {
    if (this.immuneToSlow) return;
    this.slowFactor = factor;
    this.slowTimer = Math.max(this.slowTimer, duration);
  }

  takeDamage(amount, isPhysical = true) {
    let finalDmg = amount;
    if (isPhysical && this.armor > 0) {
      finalDmg *= (1 - this.armor);
    }
    this.hp -= finalDmg;
    if (this.hp <= 0) {
      this.hp = 0;
      this.isDead = true;
    }
    return finalDmg;
  }

  update(dt) {
    if (this.isDead || this.reachedExit) return;

    if (this.slowTimer > 0) {
      this.slowTimer -= dt;
      this.speed = this.baseSpeed * this.slowFactor;
      if (this.slowTimer <= 0) {
        this.speed = this.baseSpeed;
        this.slowFactor = 1.0;
      }
    } else {
      this.speed = this.baseSpeed;
    }

    const target = this.waypoints[this.waypointIndex + 1];
    if (!target) {
      this.reachedExit = true;
      return;
    }

    const dx = target.x - this.x;
    const dy = target.y - this.y;
    const dist = Math.hypot(dx, dy);
    this.angle = Math.atan2(dy, dx);

    const step = this.speed * 60 * dt;

    if (dist <= step) {
      this.x = target.x;
      this.y = target.y;
      this.distanceTraveled += dist;
      this.waypointIndex++;
      if (this.waypointIndex >= this.waypoints.length - 1) {
        this.reachedExit = true;
      }
    } else {
      this.x += (dx / dist) * step;
      this.y += (dy / dist) * step;
      this.distanceTraveled += step;
    }
  }

  draw(ctx) {
    if (this.isDead) return;

    ctx.save();
    ctx.translate(this.x, this.y);

    // Тень
    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.beginPath();
    ctx.arc(1, 2, this.radius, 0, Math.PI * 2);
    ctx.fill();

    // Тело моба
    ctx.fillStyle = this.spec.color;
    ctx.beginPath();
    ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = this.slowTimer > 0 ? '#38bdf8' : '#111827';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Направление движения
    ctx.rotate(this.angle);
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.moveTo(this.radius * 0.6, 0);
    ctx.lineTo(-this.radius * 0.3, -this.radius * 0.4);
    ctx.lineTo(-this.radius * 0.1, 0);
    ctx.lineTo(-this.radius * 0.3, this.radius * 0.4);
    ctx.closePath();
    ctx.fill();

    ctx.restore();

    // Полоска HP
    const barW = Math.max(22, this.radius * 2);
    const barH = 3;
    const barX = this.x - barW / 2;
    const barY = this.y - this.radius - 6;
    const ratio = Math.max(0, this.hp / this.maxHp);

    ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
    ctx.fillRect(barX, barY, barW, barH);

    ctx.fillStyle = ratio > 0.5 ? '#22c55e' : (ratio > 0.25 ? '#eab308' : '#ef4444');
    ctx.fillRect(barX, barY, barW * ratio, barH);
  }
}

// 5. Снаряд
class Projectile {
  constructor(x, y, target, tower) {
    this.x = x;
    this.y = y;
    this.target = target;
    this.tower = tower;
    this.speed = tower.bulletSpeed;
    this.damage = tower.damage;
    this.splash = tower.splash;
    this.slowFactor = tower.slowFactor || 1.0;
    this.slowDuration = tower.slowDuration || 0;
    this.color = tower.color;
    this.type = tower.typeKey;

    this.hit = false;
    this.targetPos = { x: target.x, y: target.y };
  }

  update(dt, enemies, particles, audio) {
    if (this.hit) return;

    if (!this.target.isDead) {
      this.targetPos = { x: this.target.x, y: this.target.y };
    }

    const dx = this.targetPos.x - this.x;
    const dy = this.targetPos.y - this.y;
    const dist = Math.hypot(dx, dy);
    const step = this.speed * 60 * dt;

    if (dist <= step || dist < 8) {
      this.hit = true;
      this.onHit(enemies, particles, audio);
    } else {
      this.x += (dx / dist) * step;
      this.y += (dy / dist) * step;
    }
  }

  onHit(enemies, particles, audio) {
    if (this.splash > 0) {
      audio.playExplosion();
      particles.addExplosion(this.x, this.y, this.splash, this.color);

      enemies.forEach(enemy => {
        const d = Math.hypot(enemy.x - this.x, enemy.y - this.y);
        if (d <= this.splash + enemy.radius) {
          const dmgRatio = 1 - (d / (this.splash + enemy.radius)) * 0.4;
          const actualDmg = enemy.takeDamage(this.damage * dmgRatio, true);
          this.tower.damageDealt += Math.round(actualDmg);
          particles.addDamageNumber(enemy.x, enemy.y, Math.round(actualDmg));

          if (this.slowDuration > 0) {
            enemy.applySlow(this.slowFactor, this.slowDuration);
          }
        }
      });
    } else {
      if (!this.target.isDead) {
        const actualDmg = this.target.takeDamage(this.damage, this.type !== 'tesla');
        this.tower.damageDealt += Math.round(actualDmg);
        particles.addDamageNumber(this.target.x, this.target.y, Math.round(actualDmg));

        if (this.slowDuration > 0) {
          this.target.applySlow(this.slowFactor, this.slowDuration);
        }
      }
    }
  }

  draw(ctx) {
    if (this.hit) return;
    ctx.fillStyle = this.color;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.type === 'cannon' ? 5 : 3, 0, Math.PI * 2);
    ctx.fill();
  }
}

// 6. Башня
class Tower {
  constructor(typeKey, col, row, tileSize) {
    this.typeKey = typeKey;
    this.col = col;
    this.row = row;
    this.tileSize = tileSize;
    this.x = col * tileSize + tileSize / 2;
    this.y = row * tileSize + tileSize / 2;

    const spec = TOWER_SPECS[typeKey];
    this.spec = spec;

    this.level = 1;
    this.maxLevel = 3;

    this.range = spec.range;
    this.damage = spec.damage;
    this.fireRate = spec.fireRate;
    this.bulletSpeed = spec.bulletSpeed;
    this.splash = spec.splash;
    this.slowFactor = spec.slowFactor || 1.0;
    this.slowDuration = spec.slowDuration || 0;
    this.color = spec.color;

    this.cooldown = 0;
    this.target = null;
    this.angle = 0;
    this.damageDealt = 0;
    this.priority = 'first';
    this.totalInvested = spec.cost;
  }

  getUpgradeCost() {
    if (this.level >= this.maxLevel) return null;
    return Math.round(this.spec.cost * (this.level === 1 ? 0.9 : 1.5));
  }

  getSellValue() {
    return Math.round(this.totalInvested * 0.7);
  }

  upgrade() {
    if (this.level >= this.maxLevel) return false;
    const cost = this.getUpgradeCost();
    this.level++;
    this.totalInvested += cost;

    this.damage = Math.round(this.damage * 1.5);
    this.range = Math.round(this.range * 1.15);
    this.fireRate = Number((this.fireRate * 1.15).toFixed(2));
    if (this.splash > 0) this.splash = Math.round(this.splash * 1.2);
    if (this.slowDuration > 0) this.slowDuration += 0.8;

    return true;
  }

  findTarget(enemies) {
    const inRange = enemies.filter(enemy => {
      if (enemy.isDead || enemy.reachedExit) return false;
      const d = Math.hypot(enemy.x - this.x, enemy.y - this.y);
      return d <= this.range + enemy.radius;
    });

    if (inRange.length === 0) return null;

    switch (this.priority) {
      case 'strongest':
        return inRange.reduce((max, e) => (e.hp > max.hp ? e : max), inRange[0]);
      case 'weakest':
        return inRange.reduce((min, e) => (e.hp < min.hp ? e : min), inRange[0]);
      case 'closest':
        return inRange.reduce((closest, e) => {
          const d1 = Math.hypot(e.x - this.x, e.y - this.y);
          const d2 = Math.hypot(closest.x - this.x, closest.y - this.y);
          return d1 < d2 ? e : closest;
        }, inRange[0]);
      case 'first':
      default:
        return inRange.reduce((first, e) => (e.distanceTraveled > first.distanceTraveled ? e : first), inRange[0]);
    }
  }

  update(dt, enemies, projectiles, particles, audio) {
    if (this.cooldown > 0) {
      this.cooldown -= dt;
    }

    this.target = this.findTarget(enemies);

    if (this.target) {
      this.angle = Math.atan2(this.target.y - this.y, this.target.x - this.x);

      if (this.cooldown <= 0) {
        this.shoot(projectiles, particles, audio);
        this.cooldown = 1 / this.fireRate;
      }
    }
  }

  shoot(projectiles, particles, audio) {
    if (!this.target) return;

    if (this.typeKey === 'tesla') {
      audio.playShootTesla();
      const actualDmg = this.target.takeDamage(this.damage, false);
      this.damageDealt += Math.round(actualDmg);
      particles.addTeslaArc(this.x, this.y, this.target.x, this.target.y);
      particles.addDamageNumber(this.target.x, this.target.y, Math.round(actualDmg));
    } else {
      if (this.typeKey === 'gatling') audio.playShootGatling();
      else if (this.typeKey === 'cannon') audio.playShootCannon();
      else if (this.typeKey === 'frost') audio.playShootFrost();
      else if (this.typeKey === 'sniper') audio.playShootSniper();

      projectiles.push(new Projectile(this.x, this.y, this.target, this));
    }
  }

  draw(ctx, isSelected = false) {
    if (isSelected) {
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.range, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(59, 130, 246, 0.08)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(59, 130, 246, 0.6)';
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    ctx.save();
    ctx.translate(this.x, this.y);

    // Основание башни
    ctx.fillStyle = '#1e2530';
    ctx.fillRect(-15, -15, 30, 30);
    ctx.strokeStyle = '#374151';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(-15, -15, 30, 30);

    // Звезды уровня
    ctx.fillStyle = '#f59e0b';
    for (let i = 0; i < this.level; i++) {
      ctx.fillRect(-11 + i * 8, 9, 5, 3);
    }

    // Поворот турели
    ctx.rotate(this.angle);

    if (this.typeKey === 'gatling') {
      ctx.fillStyle = '#64748b';
      ctx.fillRect(4, -4, 12, 3);
      ctx.fillRect(4, 1, 12, 3);
      ctx.fillStyle = '#0284c7';
      ctx.beginPath();
      ctx.arc(0, 0, 8, 0, Math.PI * 2);
      ctx.fill();
    } else if (this.typeKey === 'cannon') {
      ctx.fillStyle = '#451a03';
      ctx.fillRect(0, -4, 14, 8);
      ctx.fillStyle = '#b45309';
      ctx.beginPath();
      ctx.arc(0, 0, 10, 0, Math.PI * 2);
      ctx.fill();
    } else if (this.typeKey === 'frost') {
      ctx.fillStyle = '#0369a1';
      ctx.beginPath();
      ctx.arc(0, 0, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(2, -2, 8, 4);
    } else if (this.typeKey === 'tesla') {
      ctx.fillStyle = '#6b21a8';
      ctx.beginPath();
      ctx.arc(0, 0, 9, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#c084fc';
      ctx.beginPath();
      ctx.arc(6, 0, 3.5, 0, Math.PI * 2);
      ctx.fill();
    } else if (this.typeKey === 'sniper') {
      ctx.fillStyle = '#14532d';
      ctx.fillRect(2, -2, 18, 4);
      ctx.fillStyle = '#16a34a';
      ctx.beginPath();
      ctx.arc(0, 0, 8, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  }
}

// 7. Система частиц
class ParticleSystem {
  constructor() {
    this.particles = [];
    this.texts = [];
    this.teslaArcs = [];
  }

  addExplosion(x, y, radius, color) {
    for (let i = 0; i < 12; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 20 + Math.random() * radius;
      this.particles.push({
        x, y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 0.35,
        maxLife: 0.35,
        radius: 3,
        color
      });
    }
  }

  addTeslaArc(x1, y1, x2, y2) {
    this.teslaArcs.push({
      x1, y1, x2, y2,
      life: 0.1,
      maxLife: 0.1
    });
  }

  addDamageNumber(x, y, amount) {
    this.texts.push({
      x: x + (Math.random() - 0.5) * 8,
      y: y - 8,
      text: `-${amount}`,
      color: '#f87171',
      life: 0.5,
      maxLife: 0.5
    });
  }

  addFloatingGold(x, y, amount) {
    this.texts.push({
      x,
      y: y - 10,
      text: `+${amount} G`,
      color: '#f59e0b',
      life: 0.7,
      maxLife: 0.7
    });
  }

  update(dt) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.life -= dt;
      if (p.life <= 0) this.particles.splice(i, 1);
    }

    for (let i = this.texts.length - 1; i >= 0; i--) {
      const t = this.texts[i];
      t.y -= 20 * dt;
      t.life -= dt;
      if (t.life <= 0) this.texts.splice(i, 1);
    }

    for (let i = this.teslaArcs.length - 1; i >= 0; i--) {
      const arc = this.teslaArcs[i];
      arc.life -= dt;
      if (arc.life <= 0) this.teslaArcs.splice(i, 1);
    }
  }

  draw(ctx) {
    // Молнии Тесла
    ctx.strokeStyle = '#c084fc';
    ctx.lineWidth = 2;
    this.teslaArcs.forEach(arc => {
      ctx.beginPath();
      ctx.moveTo(arc.x1, arc.y1);
      const segments = 4;
      for (let s = 1; s < segments; s++) {
        const t = s / segments;
        const lx = arc.x1 + (arc.x2 - arc.x1) * t;
        const ly = arc.y1 + (arc.y2 - arc.y1) * t;
        ctx.lineTo(lx + (Math.random() - 0.5) * 10, ly + (Math.random() - 0.5) * 10);
      }
      ctx.lineTo(arc.x2, arc.y2);
      ctx.stroke();
    });

    // Частицы
    this.particles.forEach(p => {
      const alpha = Math.max(0, p.life / p.maxLife);
      ctx.fillStyle = p.color;
      ctx.globalAlpha = alpha;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1.0;
    });

    // Цифры урона и золота
    ctx.font = '600 12px Inter, sans-serif';
    ctx.textAlign = 'center';
    this.texts.forEach(t => {
      const alpha = Math.max(0, t.life / t.maxLife);
      ctx.fillStyle = t.color;
      ctx.globalAlpha = alpha;
      ctx.fillText(t.text, t.x, t.y);
      ctx.globalAlpha = 1.0;
    });
  }
}

// 8. Менеджер волн
class WaveManager {
  constructor(waypoints) {
    this.waypoints = waypoints;
    this.currentWave = 0;
    this.totalWaves = 20;

    this.spawnQueue = [];
    this.spawnTimer = 0;
    this.spawnInterval = 0.9;

    this.isWaveActive = false;
    this.waveFinished = false;
  }

  generateWave(waveNum) {
    const queue = [];

    if (waveNum === 1) {
      for (let i = 0; i < 8; i++) queue.push('scout');
    } else if (waveNum === 2) {
      for (let i = 0; i < 10; i++) queue.push('scout');
      for (let i = 0; i < 4; i++) queue.push('soldier');
    } else if (waveNum === 3) {
      for (let i = 0; i < 8; i++) queue.push('soldier');
      for (let i = 0; i < 6; i++) queue.push('runner');
    } else if (waveNum === 4) {
      for (let i = 0; i < 8; i++) queue.push('soldier');
      queue.push('tank');
      for (let i = 0; i < 6; i++) queue.push('runner');
    } else if (waveNum === 5) {
      for (let i = 0; i < 6; i++) queue.push('soldier');
      queue.push('boss');
      for (let i = 0; i < 6; i++) queue.push('scout');
    } else if (waveNum === 6) {
      for (let i = 0; i < 8; i++) queue.push('flyer');
      for (let i = 0; i < 6; i++) queue.push('soldier');
    } else if (waveNum === 10) {
      queue.push('tank');
      queue.push('tank');
      queue.push('boss');
      for (let i = 0; i < 12; i++) queue.push('runner');
    } else if (waveNum === 15) {
      queue.push('boss');
      for (let i = 0; i < 14; i++) queue.push('flyer');
      queue.push('tank');
      queue.push('tank');
    } else if (waveNum === 20) {
      queue.push('tank');
      queue.push('tank');
      queue.push('boss');
      for (let i = 0; i < 14; i++) queue.push('runner');
      queue.push('boss');
      for (let i = 0; i < 10; i++) queue.push('flyer');
    } else {
      const scoutCount = Math.max(0, 12 - waveNum);
      const soldierCount = 6 + Math.round(waveNum * 1.1);
      const runnerCount = Math.round(waveNum * 0.8);
      const tankCount = Math.floor(waveNum / 3);
      const flyerCount = waveNum > 6 ? Math.round(waveNum * 0.7) : 0;

      for (let i = 0; i < scoutCount; i++) queue.push('scout');
      for (let i = 0; i < soldierCount; i++) queue.push('soldier');
      for (let i = 0; i < runnerCount; i++) queue.push('runner');
      for (let i = 0; i < tankCount; i++) queue.push('tank');
      for (let i = 0; i < flyerCount; i++) queue.push('flyer');
    }

    return queue;
  }

  startNextWave() {
    if (this.isWaveActive || this.currentWave >= this.totalWaves) return false;
    this.currentWave++;
    this.spawnQueue = this.generateWave(this.currentWave);
    this.spawnTimer = 0.5;
    this.spawnInterval = Math.max(0.4, 0.9 - this.currentWave * 0.02);
    this.isWaveActive = true;
    this.waveFinished = false;
    return true;
  }

  update(dt, enemies) {
    if (!this.isWaveActive) return;

    if (this.spawnQueue.length > 0) {
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) {
        const nextType = this.spawnQueue.shift();
        enemies.push(new Enemy(nextType, this.currentWave, this.waypoints));
        this.spawnTimer = this.spawnInterval;
      }
    } else if (enemies.length === 0) {
      this.isWaveActive = false;
      this.waveFinished = true;
    }
  }
}

// 9. Главный класс игры
class Game {
  constructor() {
    this.canvas = document.getElementById('gameCanvas');
    this.ctx = this.canvas.getContext('2d');

    this.setupHighDPI();

    this.lives = 20;
    this.gold = 450;
    this.score = 0;
    this.kills = 0;
    this.speedMultiplier = 1;
    this.isPaused = false;
    this.autoWave = false;

    this.selectedBuildType = null;
    this.selectedPlacedTower = null;

    this.audio = new AudioController();
    this.map = new GameMap(24, 15, 40);
    this.waveManager = new WaveManager(this.map.pixelWaypoints);
    this.particles = new ParticleSystem();

    this.towers = [];
    this.enemies = [];
    this.projectiles = [];

    this.mouse = { x: -100, y: -100, col: -1, row: -1, isOverCanvas: false };
    this.lastTime = performance.now();

    this.initDOM();
    this.bindEvents();
    this.updateHUD();

    requestAnimationFrame(this.loop.bind(this));
  }

  setupHighDPI() {
    const dpr = window.devicePixelRatio || 1;
    this.canvas.width = 960 * dpr;
    this.canvas.height = 600 * dpr;
    this.ctx.scale(dpr, dpr);
  }

  initDOM() {
    this.domLives = document.getElementById('stat-lives');
    this.domGold = document.getElementById('stat-gold');
    this.domWave = document.getElementById('stat-wave');
    this.domScore = document.getElementById('stat-score');

    this.btnStartWave = document.getElementById('btn-start-wave');
    this.waveBtnText = document.getElementById('wave-btn-text');
    this.checkAutoWave = document.getElementById('check-auto-wave');

    this.banner = document.getElementById('wave-banner');
    this.bannerTitle = document.getElementById('banner-title');

    this.inspectEmpty = document.getElementById('inspect-empty');
    this.inspectDetails = document.getElementById('inspect-details');
    this.inspectTitle = document.getElementById('inspect-title');
    this.inspectLvl = document.getElementById('inspect-lvl');
    this.inspectDps = document.getElementById('inspect-dps');
    this.inspectRange = document.getElementById('inspect-range');
    this.inspectFirerate = document.getElementById('inspect-firerate');
    this.inspectDamageDealt = document.getElementById('inspect-damage-dealt');
    this.btnUpgrade = document.getElementById('btn-upgrade');
    this.btnSell = document.getElementById('btn-sell');
    this.upgradeCost = document.getElementById('upgrade-cost');
    this.sellCost = document.getElementById('sell-cost');

    this.endModal = document.getElementById('end-modal');
    this.helpModal = document.getElementById('help-modal');
  }

  bindEvents() {
    this.canvas.addEventListener('mousemove', (e) => {
      const rect = this.canvas.getBoundingClientRect();
      const scaleX = 960 / rect.width;
      const scaleY = 600 / rect.height;

      this.mouse.x = (e.clientX - rect.left) * scaleX;
      this.mouse.y = (e.clientY - rect.top) * scaleY;
      this.mouse.col = Math.floor(this.mouse.x / this.map.tileSize);
      this.mouse.row = Math.floor(this.mouse.y / this.map.tileSize);
      this.mouse.isOverCanvas = true;
    });

    this.canvas.addEventListener('mouseleave', () => {
      this.mouse.isOverCanvas = false;
    });

    this.canvas.addEventListener('click', () => {
      this.audio.init();

      if (this.selectedBuildType) {
        this.buildTowerAt(this.mouse.col, this.mouse.row, this.selectedBuildType);
      } else {
        const clickedTower = this.towers.find(t => t.col === this.mouse.col && t.row === this.mouse.row);
        this.selectTower(clickedTower || null);
      }
    });

    document.querySelectorAll('.tower-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        this.audio.init();
        const type = btn.getAttribute('data-type');
        if (this.selectedBuildType === type) {
          this.setBuildType(null);
        } else {
          this.setBuildType(type);
          this.selectTower(null);
        }
      });
    });

    document.querySelectorAll('.speed-selector .btn-speed').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.speed-selector .btn-speed').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.speedMultiplier = parseFloat(btn.getAttribute('data-speed'));
      });
    });

    const btnSound = document.getElementById('btn-sound');
    btnSound.addEventListener('click', () => {
      this.audio.init();
      const muted = this.audio.toggleMute();
      btnSound.textContent = muted ? 'Звук: Выкл' : 'Звук: Вкл';
    });

    this.btnStartWave.addEventListener('click', () => {
      this.audio.init();
      this.triggerNextWave();
    });

    this.checkAutoWave.addEventListener('change', (e) => {
      this.autoWave = e.target.checked;
    });

    this.btnUpgrade.addEventListener('click', () => {
      if (this.selectedPlacedTower) {
        this.upgradeTower(this.selectedPlacedTower);
      }
    });

    this.btnSell.addEventListener('click', () => {
      if (this.selectedPlacedTower) {
        this.sellTower(this.selectedPlacedTower);
      }
    });

    document.querySelectorAll('.btn-prio').forEach(btn => {
      btn.addEventListener('click', () => {
        if (!this.selectedPlacedTower) return;
        const prio = btn.getAttribute('data-prio');
        this.selectedPlacedTower.priority = prio;
        document.querySelectorAll('.btn-prio').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      });
    });

    window.addEventListener('keydown', (e) => {
      this.audio.init();

      if (e.code === 'Space') {
        e.preventDefault();
        if (!this.waveManager.isWaveActive) {
          this.triggerNextWave();
        } else {
          this.isPaused = !this.isPaused;
        }
      } else if (e.code === 'Digit1') this.setBuildType('gatling');
      else if (e.code === 'Digit2') this.setBuildType('cannon');
      else if (e.code === 'Digit3') this.setBuildType('frost');
      else if (e.code === 'Digit4') this.setBuildType('tesla');
      else if (e.code === 'Digit5') this.setBuildType('sniper');
      else if (e.code === 'KeyU') {
        if (this.selectedPlacedTower) this.upgradeTower(this.selectedPlacedTower);
      } else if (e.code === 'KeyS') {
        if (this.selectedPlacedTower) this.sellTower(this.selectedPlacedTower);
      } else if (e.code === 'Escape') {
        this.setBuildType(null);
        this.selectTower(null);
      } else if (e.code === 'KeyM') {
        const muted = this.audio.toggleMute();
        btnSound.textContent = muted ? 'Звук: Выкл' : 'Звук: Вкл';
      }
    });

    document.getElementById('btn-help').addEventListener('click', () => {
      this.helpModal.classList.add('active');
    });
    document.getElementById('btn-close-help').addEventListener('click', () => {
      this.helpModal.classList.remove('active');
    });
    document.getElementById('btn-got-it').addEventListener('click', () => {
      this.helpModal.classList.remove('active');
    });
    document.getElementById('btn-restart').addEventListener('click', () => {
      this.restart();
    });
  }

  setBuildType(type) {
    this.selectedBuildType = type;
    document.querySelectorAll('.tower-btn').forEach(btn => {
      if (btn.getAttribute('data-type') === type) {
        btn.classList.add('selected');
      } else {
        btn.classList.remove('selected');
      }
    });
  }

  selectTower(tower) {
    this.selectedPlacedTower = tower;
    if (!tower) {
      this.inspectEmpty.style.display = 'block';
      this.inspectDetails.style.display = 'none';
      this.inspectTitle.textContent = 'Параметры башни';
      this.inspectLvl.textContent = 'Ур. 1';
      return;
    }

    this.inspectEmpty.style.display = 'none';
    this.inspectDetails.style.display = 'flex';
    this.inspectTitle.textContent = `${tower.spec.name}`;
    this.inspectLvl.textContent = `Ур. ${tower.level}`;

    this.updateInspectorStats();
  }

  updateInspectorStats() {
    const t = this.selectedPlacedTower;
    if (!t) return;

    this.inspectLvl.textContent = `Ур. ${t.level} / ${t.maxLevel}`;
    const dps = Math.round(t.damage * t.fireRate);
    this.inspectDps.textContent = `${dps} (${t.damage}/выстр.)`;
    this.inspectRange.textContent = `${t.range} px`;
    this.inspectFirerate.textContent = `${t.fireRate} / с`;
    this.inspectDamageDealt.textContent = `${t.damageDealt}`;

    document.querySelectorAll('.btn-prio').forEach(b => {
      b.classList.toggle('active', b.getAttribute('data-prio') === t.priority);
    });

    const upgradeCost = t.getUpgradeCost();
    if (upgradeCost !== null) {
      this.btnUpgrade.disabled = this.gold < upgradeCost;
      this.upgradeCost.textContent = `${upgradeCost} G`;
    } else {
      this.btnUpgrade.disabled = true;
      this.upgradeCost.textContent = `MAX`;
    }

    const sellVal = t.getSellValue();
    this.sellCost.textContent = `+${sellVal} G`;
  }

  buildTowerAt(col, row, typeKey) {
    const spec = TOWER_SPECS[typeKey];
    if (this.gold < spec.cost) return;
    if (!this.map.canBuildAt(col, row, this.towers)) return;

    this.gold -= spec.cost;
    const tower = new Tower(typeKey, col, row, this.map.tileSize);
    this.towers.push(tower);
    this.audio.playBuild();

    this.setBuildType(null);
    this.selectTower(tower);
    this.updateHUD();
  }

  upgradeTower(tower) {
    const cost = tower.getUpgradeCost();
    if (cost === null || this.gold < cost) return;

    this.gold -= cost;
    tower.upgrade();
    this.audio.playUpgrade();
    this.updateInspectorStats();
    this.updateHUD();
  }

  sellTower(tower) {
    const sellVal = tower.getSellValue();
    this.gold += sellVal;
    this.audio.playCoin();
    this.particles.addFloatingGold(tower.x, tower.y, sellVal);

    this.towers = this.towers.filter(t => t !== tower);
    this.selectTower(null);
    this.updateHUD();
  }

  triggerNextWave() {
    if (this.waveManager.isWaveActive) return;

    const started = this.waveManager.startNextWave();
    if (started) {
      this.audio.playWaveStart();
      this.showWaveBanner(this.waveManager.currentWave);
      this.btnStartWave.disabled = true;
      this.updateHUD();
    }
  }

  showWaveBanner(waveNum) {
    this.bannerTitle.textContent = `Волна ${waveNum} из ${this.waveManager.totalWaves}`;
    this.banner.classList.add('show');
    setTimeout(() => {
      this.banner.classList.remove('show');
    }, 1800);
  }

  updateHUD() {
    this.domLives.textContent = this.lives;
    this.domGold.textContent = this.gold;
    this.domWave.textContent = `${this.waveManager.currentWave} / ${this.waveManager.totalWaves}`;
    this.domScore.textContent = this.score;

    if (!this.waveManager.isWaveActive) {
      this.btnStartWave.disabled = false;
      this.waveBtnText.textContent = `Запуск волны ${this.waveManager.currentWave + 1}`;
    } else {
      this.btnStartWave.disabled = true;
      this.waveBtnText.textContent = `Идет волна...`;
    }

    document.querySelectorAll('.tower-btn').forEach(btn => {
      const type = btn.getAttribute('data-type');
      const cost = TOWER_SPECS[type].cost;
      btn.classList.toggle('disabled', this.gold < cost);
    });

    if (this.selectedPlacedTower) {
      this.updateInspectorStats();
    }
  }

  onEnemyKilled(enemy) {
    this.gold += enemy.reward;
    this.score += enemy.score;
    this.kills++;
    this.audio.playCoin();
    this.particles.addFloatingGold(enemy.x, enemy.y, enemy.reward);
    this.updateHUD();
  }

  onEnemyReachedExit(enemy) {
    this.lives -= (enemy.isBoss ? 5 : 1);
    if (this.lives <= 0) {
      this.lives = 0;
      this.gameOver(false);
    }
    this.updateHUD();
  }

  gameOver(isVictory) {
    this.isPaused = true;
    if (isVictory) {
      this.audio.playVictory();
      document.getElementById('modal-title').textContent = 'Победа!';
      document.getElementById('modal-desc').textContent = 'Все 20 волн успешно отражены.';
    } else {
      this.audio.playGameOver();
      document.getElementById('modal-title').textContent = 'Поражение';
      document.getElementById('modal-desc').textContent = 'Враги прорвали оборону базы.';
    }

    document.getElementById('end-waves').textContent = `${this.waveManager.currentWave} / ${this.waveManager.totalWaves}`;
    document.getElementById('end-kills').textContent = this.kills;
    document.getElementById('end-score').textContent = this.score;

    this.endModal.classList.add('active');
  }

  restart() {
    this.endModal.classList.remove('active');
    this.lives = 20;
    this.gold = 450;
    this.score = 0;
    this.kills = 0;
    this.isPaused = false;
    this.towers = [];
    this.enemies = [];
    this.projectiles = [];
    this.waveManager = new WaveManager(this.map.pixelWaypoints);
    this.selectTower(null);
    this.setBuildType(null);
    this.updateHUD();
  }

  loop(timestamp) {
    let dt = (timestamp - this.lastTime) / 1000;
    this.lastTime = timestamp;

    if (dt > 0.1) dt = 0.1;

    if (!this.isPaused) {
      const effectiveDt = dt * this.speedMultiplier;
      this.update(effectiveDt);
    }

    this.render();
    requestAnimationFrame(this.loop.bind(this));
  }

  update(dt) {
    this.waveManager.update(dt, this.enemies);

    if (this.waveManager.waveFinished) {
      this.waveManager.waveFinished = false;
      this.updateHUD();

      if (this.waveManager.currentWave >= this.waveManager.totalWaves && this.enemies.length === 0) {
        this.gameOver(true);
        return;
      }

      if (this.autoWave) {
        setTimeout(() => {
          if (!this.waveManager.isWaveActive && this.lives > 0) {
            this.triggerNextWave();
          }
        }, 1200);
      }
    }

    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const enemy = this.enemies[i];
      enemy.update(dt);

      if (enemy.isDead) {
        this.onEnemyKilled(enemy);
        this.enemies.splice(i, 1);
      } else if (enemy.reachedExit) {
        this.onEnemyReachedExit(enemy);
        this.enemies.splice(i, 1);
      }
    }

    this.towers.forEach(tower => {
      tower.update(dt, this.enemies, this.projectiles, this.particles, this.audio);
    });

    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const proj = this.projectiles[i];
      proj.update(dt, this.enemies, this.particles, this.audio);
      if (proj.hit) {
        this.projectiles.splice(i, 1);
      }
    }

    this.particles.update(dt);
  }

  render() {
    this.map.draw(this.ctx);

    if (this.selectedBuildType && this.mouse.isOverCanvas) {
      const col = this.mouse.col;
      const row = this.mouse.row;
      const canBuild = this.map.canBuildAt(col, row, this.towers);
      const spec = TOWER_SPECS[this.selectedBuildType];
      const cx = col * this.map.tileSize + this.map.tileSize / 2;
      const cy = row * this.map.tileSize + this.map.tileSize / 2;

      this.ctx.fillStyle = canBuild ? 'rgba(74, 222, 128, 0.2)' : 'rgba(239, 68, 68, 0.2)';
      this.ctx.fillRect(col * this.map.tileSize, row * this.map.tileSize, this.map.tileSize, this.map.tileSize);

      this.ctx.beginPath();
      this.ctx.arc(cx, cy, spec.range, 0, Math.PI * 2);
      this.ctx.fillStyle = canBuild ? 'rgba(59, 130, 246, 0.08)' : 'rgba(239, 68, 68, 0.08)';
      this.ctx.fill();
      this.ctx.strokeStyle = canBuild ? 'rgba(59, 130, 246, 0.5)' : 'rgba(239, 68, 68, 0.5)';
      this.ctx.stroke();
    }

    this.towers.forEach(tower => {
      tower.draw(this.ctx, tower === this.selectedPlacedTower);
    });

    this.projectiles.forEach(proj => {
      proj.draw(this.ctx);
    });

    this.enemies.forEach(enemy => {
      enemy.draw(this.ctx);
    });

    this.particles.draw(this.ctx);

    if (this.isPaused && this.lives > 0) {
      this.ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
      this.ctx.fillRect(0, 0, 960, 600);
      this.ctx.font = '600 24px Inter, sans-serif';
      this.ctx.fillStyle = '#fff';
      this.ctx.textAlign = 'center';
      this.ctx.fillText('ПАУЗА', 480, 300);
    }
  }
}

window.addEventListener('DOMContentLoaded', () => {
  window.game = new Game();
});
